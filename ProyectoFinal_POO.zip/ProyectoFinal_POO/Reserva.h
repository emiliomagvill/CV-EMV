#ifndef RESERVA_H_INCLUDED
#define RESERVA_H_INCLUDED

#include <iostream>

using namespace std;

class Vuelo;  // Declaraci�n adelantada de la clase Vuelo
class Pasajero;  // Declaraci�n adelantada de la clase Pasajero

class Reserva {
private:
  string IDReserva;
  Vuelo* vuelo;
  Pasajero* pasajero;
  string fechaReserva;
  string estatus;

public:
  // M�todos p�blicos para establecer y obtener la informaci�n de la reserva
  void setIDReserva(const string& ID);
  string getIDReserva() const;

  void setVuelo(Vuelo* vueloPtr);
  Vuelo* getVuelo() const;

  void setPasajero(Pasajero* pasajeroPtr);
  Pasajero* getPasajero() const;

  void setFechaReserva(const string& fecha);
  string getFechaReserva() const;

  void setEstatus(const string& estatus);
  string getEstatus() const;

  // Otros m�todos de la clase
};

#endif // RESERVA_H_INCLUDED
