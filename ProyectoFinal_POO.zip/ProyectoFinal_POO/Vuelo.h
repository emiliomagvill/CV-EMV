#ifndef VUELO_H_INCLUDED
#define VUELO_H_INCLUDED

#include <iostream>

using namespace std;

class Vuelo {
private:
  string numeroVuelo;
  string origen;
  string destino;
  string horaSalida;
  string horaLlegada;
  int asientos;

public:
  // M�todos p�blicos para establecer y obtener la informaci�n de vuelo
  void setNumeroVuelo(const string& numero);
  string getNumeroVuelo() const;

  void setOrigen(const string& origen);
  string getOrigen() const;

  void setDestino(const string& destino);
  string getDestino() const;

  void setHoraSalida(const string& horaSalida);
  string getHoraSalida() const;

  void setHoraLlegada(const string& horaLlegada);
  string getHoraLlegada() const;

  void setAsientos(int asientos);
  int getAsientos() const;

  // Otros m�todos de la clase
};


#endif // VUELO_H_INCLUDED
