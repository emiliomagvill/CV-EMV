#include "Vuelo.h"

using namespace std;

void Vuelo::setNumeroVuelo(const string& numero) {
  numeroVuelo = numero;
}

string Vuelo::getNumeroVuelo() const {
  return numeroVuelo;
}

void Vuelo::setOrigen(const string& origen) {
  this->origen = origen;
}

string Vuelo::getOrigen() const {
  return origen;
}

void Vuelo::setDestino(const string& destino) {
  this->destino = destino;
}

string Vuelo::getDestino() const {
  return destino;
}

void Vuelo::setHoraSalida(const string& horaSalida) {
  this->horaSalida = horaSalida;
}

string Vuelo::getHoraSalida() const {
  return horaSalida;
}

void Vuelo::setHoraLlegada(const string& horaLlegada) {
  this->horaLlegada = horaLlegada;
}

string Vuelo::getHoraLlegada() const {
  return horaLlegada;
}

void Vuelo::setAsientos(int asientos) {
  this->asientos = asientos;
}

int Vuelo::getAsientos() const {
  return asientos;
}
