#include "AgenciaDeViajes.h"

void AgenciaDeViajes::setNombre(const string& nombre) {
    this->nombre = nombre;
}

string AgenciaDeViajes::getNombre() const {
    return nombre;
}

void AgenciaDeViajes::setDireccion(const string& direccion) {
    this->direccion = direccion;
}

string AgenciaDeViajes::getDireccion() const {
    return direccion;
}
