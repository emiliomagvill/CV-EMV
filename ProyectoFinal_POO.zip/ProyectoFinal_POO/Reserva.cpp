#include "Reserva.h"
#include "Vuelo.h"
#include "Pasajero.h"

void Reserva::setIDReserva(const string& ID) {
  IDReserva = ID;
}

string Reserva::getIDReserva() const {
  return IDReserva;
}

void Reserva::setVuelo(Vuelo* vueloPtr) {
  vuelo = vueloPtr;
}

Vuelo* Reserva::getVuelo() const {
  return vuelo;
}

void Reserva::setPasajero(Pasajero* pasajeroPtr) {
  pasajero = pasajeroPtr;
}

Pasajero* Reserva::getPasajero() const {
  return pasajero;
}

void Reserva::setFechaReserva(const string& fecha) {
  fechaReserva = fecha;
}

string Reserva::getFechaReserva() const {
  return fechaReserva;
}

void Reserva::setEstatus(const string& estatus) {
  this->estatus = estatus;
}

string Reserva::getEstatus() const {
  return estatus;
}
