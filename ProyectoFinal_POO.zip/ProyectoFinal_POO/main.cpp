#include <iostream>
#include "Vuelo.h"
#include "Aeropuerto.h"
#include "Pasajero.h"
#include "Reserva.h"
#include "AgenciaDeViajes.h"

using namespace std;

int main() {
  // Crear un nuevo pasajero
  Pasajero* pasajero = new Pasajero();
  pasajero->setID("123");
  pasajero->setEmail("pasajero@example.com");

  // Crear un nuevo vuelo
  Vuelo* vuelo = new Vuelo();
  vuelo->setNumeroVuelo("FL123");
  vuelo->setOrigen("Aeropuerto A");
  vuelo->setDestino("Aeropuerto B");
  vuelo->setHoraSalida("10:00");
  vuelo->setHoraLlegada("12:00");
  vuelo->setAsientos(100);

  // Crear una nueva reserva para el pasajero y el vuelo
  Reserva* reserva = new Reserva();
  reserva->setIDReserva("R123");
  reserva->setVuelo(vuelo);
  reserva->setPasajero(pasajero);
  reserva->setFechaReserva("2023-06-15");
  reserva->setEstatus("Confirmada");

  // Acceder a la informaci�n de la reserva
  cout << "Informaci�n de la reserva" << endl;
  cout << "ID de reserva: " << reserva->getIDReserva() << endl;
  cout << "Vuelo: " << vuelo->getNumeroVuelo() << endl;
  cout << "Pasajero: " << pasajero->getID() << endl;
  cout << "Fecha de reserva: " << reserva->getFechaReserva() << endl;
  cout << "Estatus: " << reserva->getEstatus() << endl;


    // Crear una nueva agencia de viajes
    AgenciaDeViajes* agencia = new AgenciaDeViajes();
    agencia->setNombre("Viajes Express");
    agencia->setDireccion("Calle Principal 123");
    cout << " " << endl;
    cout << "Detalles de la agencia de viajes" << endl;
    cout << "Nombre: " << agencia->getNombre() << endl;
    cout << "Direcci�n: " << agencia->getDireccion() << endl;

  // Liberar la memoria de los objetos creados
  delete reserva;
  delete vuelo;
  delete pasajero;

  return 0;
}
