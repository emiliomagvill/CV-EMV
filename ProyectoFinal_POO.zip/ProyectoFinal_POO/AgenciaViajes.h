#ifndef AGENCIAVIAJES_H_INCLUDED
#define AGENCIAVIAJES_H_INCLUDED

#include <iostream>

using namespace std;


class AgenciaDeViajes {
private:
    string nombre;
    string direccion;
public:
    void setNombre(const string& nombre);
    string getNombre() const;
    void setDireccion(const string& direccion);
    string getDireccion() const;
};


#endif // AGENCIAVIAJES_H_INCLUDED
