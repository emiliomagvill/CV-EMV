#ifndef AGENCIADEVIAJES_H_INCLUDED
#define AGENCIADEVIAJES_H_INCLUDED

#include <iostream>

using namespace std;


class AgenciaDeViajes {
private:
    string nombre;
    string direccion;
public:
    void setNombre(const string& nombre);
    string getNombre() const;
    void setDireccion(const string& direccion);
    string getDireccion() const;
};


#endif // AGENCIADEVIAJES_H_INCLUDED
