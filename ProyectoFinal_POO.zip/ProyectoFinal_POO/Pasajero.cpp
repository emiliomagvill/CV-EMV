#include "Pasajero.h"

void Pasajero::setID(const string& id) {
  ID = id;
}

string Pasajero::getID() const {
  return ID;
}

void Pasajero::setEmail(const string& email) {
  this->email = email;
}

string Pasajero::getEmail() const {
  return email;
}
