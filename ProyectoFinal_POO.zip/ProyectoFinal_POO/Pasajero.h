#ifndef PASAJERO_H_INCLUDED
#define PASAJERO_H_INCLUDED

#include <iostream>

using namespace std;

class Pasajero {
private:
  string ID;
  string email;

public:
  // M�todos p�blicos para establecer y obtener la informaci�n del pasajero
  void setID(const string& id);
  string getID() const;

  void setEmail(const string& email);
  string getEmail() const;

  // Otros m�todos de la clase
};

#endif // PASAJERO_H_INCLUDED
